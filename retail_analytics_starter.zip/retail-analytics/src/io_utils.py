from pathlib import Path
import pandas as pd
import yaml

BASE = Path(__file__).resolve().parents[1]

def load_config(name="project.yaml"):
    with open(BASE / "configs" / name, "r") as f:
        return yaml.safe_load(f)

def read_csv(path: str, **kwargs) -> pd.DataFrame:
    return pd.read_csv(BASE / path, **kwargs)

def write_csv(df: pd.DataFrame, path: str, index=False, **kwargs):
    out = BASE / path
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=index, **kwargs)
