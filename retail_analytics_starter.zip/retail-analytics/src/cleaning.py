from __future__ import annotations
from pathlib import Path
import pandas as pd
import numpy as np
import pandera as pa
from pandera import Column, Check
from .io_utils import load_config, write_csv, BASE

# -----------------
# Schema definitions
# -----------------
class TxnSchema(pa.DataFrameModel):
    order_id: Column[str] = Column(str, nullable=False)
    order_date: Column[str] = Column(str, nullable=False)  # parse to datetime in clean()
    customer_id: Column[str] = Column(str, nullable=False)
    qty: Column[float] = Column(float, Check.ge(0), nullable=False)
    unit_price: Column[float] = Column(float, Check.ge(0), nullable=False)
    discount: Column[float] = Column(float, nullable=True)  # absolute amount; set to 0 if missing
    currency: Column[str] = Column(str, nullable=True)
    sku: Column[str] = Column(str, nullable=True)

def _parse_dates(df: pd.DataFrame, col: str = "order_date") -> pd.DataFrame:
    df[col] = pd.to_datetime(df[col], errors="coerce")
    return df

def _normalize_numbers(df: pd.DataFrame) -> pd.DataFrame:
    if "discount" not in df.columns:
        df["discount"] = 0.0
    df["discount"] = df["discount"].fillna(0.0)
    # clip unreasonable values
    df["qty"] = pd.to_numeric(df["qty"], errors="coerce").fillna(0)
    df["unit_price"] = pd.to_numeric(df["unit_price"], errors="coerce").fillna(0.0)
    df["discount"] = pd.to_numeric(df["discount"], errors="coerce").fillna(0.0)
    return df

def _drop_invalid(df: pd.DataFrame) -> pd.DataFrame:
    # Drop rows with missing critical fields
    crit = ["order_id", "order_date", "customer_id"]
    df = df.dropna(subset=[c for c in crit if c in df.columns])
    # Remove zero or negative quantities/prices
    if "qty" in df.columns:
        df = df[df["qty"] > 0]
    if "unit_price" in df.columns:
        df = df[df["unit_price"] >= 0]
    return df

def _dedupe(df: pd.DataFrame) -> pd.DataFrame:
    keep_cols = [c for c in ["order_id", "customer_id", "sku", "order_date", "qty", "unit_price", "discount"] if c in df.columns]
    return df.drop_duplicates(subset=keep_cols, keep="first")

def _compute_amounts(df: pd.DataFrame) -> pd.DataFrame:
    # Treat discount as absolute by default
    df["line_amount_gross"] = df["qty"] * df["unit_price"]
    df["line_amount_net"] = df["line_amount_gross"] - df["discount"].fillna(0.0)
    # prevent negative nets
    df["line_amount_net"] = df["line_amount_net"].clip(lower=0.0)
    return df

def clean_transactions(transactions_path: str, out_path: str = "data/interim/transactions_clean.csv") -> pd.DataFrame:
    cfg = load_config()
    df = pd.read_csv(BASE / transactions_path)
    # Basic column normalization
    df = df.rename(columns={
        "OrderID":"order_id","OrderId":"order_id","orderId":"order_id",
        "OrderDate":"order_date","Order_Date":"order_date",
        "CustomerID":"customer_id","CustomerId":"customer_id","customerId":"customer_id",
        "Quantity":"qty","Qty":"qty",
        "UnitPrice":"unit_price","Price":"unit_price",
        "DiscountAmount":"discount","Discount":"discount"
    })
    # validate presence
    required = {"order_id","order_date","customer_id","qty","unit_price"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    # typed cleaning
    df = _parse_dates(df, "order_date")
    df = _normalize_numbers(df)
    df = _drop_invalid(df)
    df = _dedupe(df)
    df = _compute_amounts(df)
    # add day/week/month for later use
    df["order_date"] = df["order_date"].dt.tz_localize("Asia/Kolkata", nonexistent="shift_forward", ambiguous="NaT", errors="ignore") if df["order_date"].dt.tz is None else df["order_date"]
    dti = df["order_date"].dt.tz_convert("Asia/Kolkata") if df["order_date"].dt.tz is not None else df["order_date"]
    df["order_day"] = dti.dt.date
    df["order_month"] = dti.dt.to_period("M").astype(str)
    # write
    write_csv(df, out_path, index=False)
    return df

def build_customer_order_agg(clean_txn_path: str = "data/interim/transactions_clean.csv",
                             out_path: str = "data/processed/customer_orders.csv") -> pd.DataFrame:
    df = pd.read_csv(BASE / clean_txn_path, parse_dates=["order_date"])
    # order-level aggregates
    order_totals = (df
        .groupby(["order_id","customer_id","order_day"], as_index=False)
        .agg({"line_amount_net":"sum","qty":"sum"})
        .rename(columns={"line_amount_net":"order_amount","qty":"order_qty"}))
    # customer daily revenue
    cust_daily = (order_totals
        .groupby(["customer_id","order_day"], as_index=False)
        .agg({"order_amount":"sum","order_qty":"sum","order_id":"nunique"})
        .rename(columns={"order_id":"orders"}))
    # save
    out = BASE / out_path
    out.parent.mkdir(parents=True, exist_ok=True)
    cust_daily.to_csv(out, index=False)
    return cust_daily

if __name__ == "__main__":
    # CLI usage: python -m src.cleaning
    tx_path = "data/raw/transactions.csv"  # put your file here
    try:
        df = clean_transactions(tx_path)
        print(f"Cleaned transactions -> data/interim/transactions_clean.csv, rows={len(df)}")
        cust = build_customer_order_agg()
        print(f"Customer daily aggregates -> data/processed/customer_orders.csv, rows={len(cust)}")
    except Exception as e:
        print("Error:", e)
