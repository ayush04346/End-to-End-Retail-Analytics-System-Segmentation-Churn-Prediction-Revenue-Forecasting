# Data Dictionary (Template)

## transactions.csv
| Column       | Type     | Description                                  | Constraints/Notes                         |
|--------------|----------|----------------------------------------------|-------------------------------------------|
| order_id     | string   | Unique order identifier                       | Required                                   |
| order_date   | datetime | Timestamp of order (Asia/Kolkata)            | Required                                   |
| customer_id  | string   | Unique customer ID                            | Required                                   |
| sku          | string   | Product SKU                                   | Optional                                   |
| qty          | number   | Quantity purchased                            | >= 0                                       |
| unit_price   | number   | Unit price (INR)                              | >= 0                                       |
| discount     | number   | Absolute discount per row (INR)               | Default 0                                  |
| currency     | string   | Currency code                                 | If multi-currency                          |

## customers.csv (optional)
| Column      | Type     | Description             |
|-------------|----------|-------------------------|
| customer_id | string   | Unique customer ID      |
| signup_date | date     | First seen/registration |
| region      | string   | City/region             |
