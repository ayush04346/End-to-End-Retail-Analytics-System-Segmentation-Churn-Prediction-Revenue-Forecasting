# Retail Analytics — Segmentation, Churn, Forecasting

This repository scaffolds an end‑to‑end retail analytics workflow:
- RFM + KMeans segmentation
- Churn prediction
- 30‑day revenue forecasting (Prophet/SARIMAX)
- KPI dashboards

## How to use
1) Create and activate a virtual environment.
2) `pip install -r requirements.txt`
3) Put your raw CSVs into `data/raw/` (see `reports/data_dictionary.md` for columns).
4) Run the data audit notebook `notebooks/01_data_audit.ipynb` or `python -m src.cleaning` for CLI.
